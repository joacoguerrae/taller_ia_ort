import torch
import torch.nn as nn
import numpy as np
from abstract_agent import Agent
from replay_memory import ReplayMemory


class DQNAgent(Agent):
    def __init__(
        self,
        env,
        model,
        obs_processing_func,
        memory_buffer_size,
        batch_size,
        learning_rate,
        gamma,
        epsilon_i,
        epsilon_f,
        epsilon_anneal_steps,
        episode_block,
        device,
    ):
        super().__init__(
            env,
            obs_processing_func,
            memory_buffer_size,
            batch_size,
            learning_rate,
            gamma,
            epsilon_i,
            epsilon_f,
            epsilon_anneal_steps,
            episode_block,
            device,
        )
        # Guardar entorno y función de preprocesamiento
        # Inicializar policy_net en device
        # Configurar función de pérdida MSE y optimizador Adam
        # Crear replay memory de tamaño buffer_size
        # Almacenar batch_size, gamma y parámetros de epsilon-greedy
        self.env = env
        self.state_processing_function = obs_processing_func

        self.policy_net = model.to(device)

        self.criterion = nn.MSELoss()
        self.optimizer = torch.optim.Adam(
            self.policy_net.parameters(), lr=learning_rate
        )

        self.memory = ReplayMemory(memory_buffer_size)

        self.batch_size = batch_size
        self.gamma = gamma
        self.epsilon_i = epsilon_i
        self.epsilon_f = epsilon_f
        self.epsilon_anneal_steps = epsilon_anneal_steps
        self.episode_block = episode_block

    def select_action(self, state, current_steps, train=True):
        # Calcular epsilon según step
        # Durante entrenamiento: con probabilidad epsilon acción aleatoria
        #                   sino greedy_action
        # Durante evaluación: usar greedy_action (o pequeña epsilon fija)
        self.epsilon = self.compute_epsilon(current_steps)
        if train:
            if np.random.rand() < self.epsilon:
                action = self.env.action_space.sample()
            else:
                with torch.no_grad():
                    state_tensor = torch.tensor(state, device=self.device).unsqueeze(0)
                    q_values = self.policy_net(state_tensor)
                    action = q_values.max(1)[1].item()
        else:
            with torch.no_grad():
                state_tensor = torch.tensor(state, device=self.device).unsqueeze(0)
                q_values = self.policy_net(state_tensor)
                action = q_values.max(1)[1].item()

        return action

    def update_weights(self):
        # 1) Comprobar que hay al menos batch_size muestras en memoria
        # 2) Muestrear minibatch y convertir a tensores (states, actions, rewards, dones, next_states)
        # 3) Calcular q_current con policy_net(states).gather(...)
        # 4) Con torch.no_grad(): calcular max_q_next_state = policy_net(next_states).max(dim=1)[0] * (1 - dones)
        # 5) Calcular target = rewards + gamma * max_q_next_state
        # 6) Computar loss MSE entre q_current y target, backprop y optimizer.step()
        pass
