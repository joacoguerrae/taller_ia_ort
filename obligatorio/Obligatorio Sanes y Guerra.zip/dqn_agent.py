import torch
import torch.nn as nn
import numpy as np
from abstract_agent import Agent
from replay_memory import ReplayMemory, Transition


class DQNAgent(Agent):
    def __init__(
        self,
        env,
        model,
        obs_processing_func,
        memory_buffer_size,
        batch_size,
        learning_rate,
        gamma,
        epsilon_i,
        epsilon_f,
        epsilon_anneal_steps,
        episode_block,
        device,
        checkpoint_interval=1000,  # Add checkpoint interval
        with_priority=False,  # DQNAgent does not use priority by default
    ):
        super().__init__(
            env,
            obs_processing_func,
            memory_buffer_size,
            batch_size,
            learning_rate,
            gamma,
            epsilon_i,
            epsilon_f,
            epsilon_anneal_steps,
            episode_block,
            device,
            checkpoint_interval,  # Pass checkpoint interval to superclass
            with_priority=False,  # DQNAgent does not use priority by default
        )
        # Guardar entorno y función de preprocesamiento
        # Inicializar policy_net en device
        # Configurar función de pérdida MSE y optimizador Adam
        # Crear replay memory de tamaño buffer_size
        # Almacenar batch_size, gamma y parámetros de epsilon-greedy
        self.env = env
        self.state_processing_function = obs_processing_func

        self.policy_net = model.to(device)

        self.criterion = nn.MSELoss()
        self.optimizer = torch.optim.Adam(
            self.policy_net.parameters(), lr=learning_rate
        )

        self.memory = ReplayMemory(memory_buffer_size)

        self.batch_size = batch_size
        self.gamma = gamma
        self.epsilon_i = epsilon_i
        self.epsilon_f = epsilon_f
        self.epsilon_anneal_steps = epsilon_anneal_steps
        self.episode_block = episode_block
        self.checkpoint_interval = checkpoint_interval
        self.with_priority = with_priority  # DQNAgent does not use priority by default

    def select_action(self, state, current_steps, train=True):
        # Calcular epsilon según step
        # Durante entrenamiento: con probabilidad epsilon acción aleatoria
        #                   sino greedy_action
        # Durante evaluación: usar greedy_action (o pequeña epsilon fija)
        self.epsilon = self.compute_epsilon(current_steps)
        if train and np.random.rand() < self.epsilon:
            action = self.env.action_space.sample()
        else:
            with torch.no_grad():
                state_tensor = state.clone().detach().unsqueeze(0)
                q_values = self.policy_net(state_tensor)
                action = q_values.argmax().item()
        return action

    def select_action_vec(self, states, current_steps, train=True):
        self.epsilon = self.compute_epsilon(current_steps)

        if train and np.random.rand() < self.epsilon:
            num_envs = states.shape[0]
            actions = [self.action_space.sample() for _ in range(num_envs)]
            return np.array(actions)
        else:
            with torch.no_grad():
                q_values = self.policy_net(states)
                actions = q_values.argmax(dim=1).cpu().numpy()
            return actions

    def update_weights(self):
        # 1) Comprobar que hay al menos batch_size muestras en memoria
        # 2) Muestrear minibatch y convertir a tensores (states, actions, rewards, dones, next_states)
        # 3) Calcular q_current con policy_net(states).gather(...)
        # 4) Con torch.no_grad(): calcular max_q_next_state = policy_net(next_states).max(dim=1)[0] * (1 - dones)
        # 5) Calcular target = rewards + gamma * max_q_next_state
        # 6) Computar loss MSE entre q_current y target, backprop y optimizer.step()
        if self.memory.__len__() < self.batch_size:
            return  # No hay suficientes muestras en memoria
        else:
            tranitions = self.memory.sample(self.batch_size)
            batch = Transition(*zip(*tranitions))

            state_batch = torch.stack(
                [
                    torch.tensor(s, dtype=torch.float32).to(self.device)
                    for s in batch.state
                ]
            )
            action_batch = torch.tensor(batch.action, device=self.device)
            reward_batch = torch.tensor(
                batch.reward, dtype=torch.float32, device=self.device
            )
            done_batch = torch.tensor(
                batch.done, dtype=torch.float32, device=self.device
            )
            next_state_batch = torch.stack(
                [
                    torch.tensor(s, dtype=torch.float32).to(self.device)
                    for s in batch.next_state
                ]
            )

            q_current = (
                self.policy_net(state_batch)
                .gather(1, action_batch.unsqueeze(1))
                .squeeze(1)
            )

            with torch.no_grad():
                max_q_next_state = self.policy_net(next_state_batch).max(dim=1)[0] * (
                    1 - done_batch
                )
                target = reward_batch + self.gamma * max_q_next_state

            loss = self.criterion(q_current, target)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            return loss.item()

    def update_weights_prio(self):
        # Verificamos que haya suficientes transiciones con prioridad
        if (
            not hasattr(self.memory, "priority_memory")
            or len(self.memory.priority_memory) < self.batch_size
        ):
            return

        # 1. Muestreo con prioridad
        transitions, indices, weights = self.memory.sample_with_priority(
            self.batch_size
        )
        batch = Transition(*zip(*transitions))

        # 2. Preprocesamiento
        state_batch = torch.stack(
            [torch.tensor(s, dtype=torch.float32).to(self.device) for s in batch.state]
        )
        action_batch = torch.tensor(batch.action, dtype=torch.long, device=self.device)
        reward_batch = torch.tensor(
            batch.reward, dtype=torch.float32, device=self.device
        )
        done_batch = torch.tensor(batch.done, dtype=torch.float32, device=self.device)
        next_state_batch = torch.stack(
            [
                torch.tensor(s, dtype=torch.float32).to(self.device)
                for s in batch.next_state
            ]
        ).to(self.device)
        weights = torch.tensor(
            weights, dtype=torch.float32, device=self.device
        )  # pesos de importancia

        # 3. Q(s,a) actual
        q_current = (
            self.policy_net(state_batch).gather(1, action_batch.unsqueeze(1)).squeeze(1)
        )

        with torch.no_grad():
            max_q_next_state = self.policy_net(next_state_batch).max(dim=1)[0] * (
                1 - done_batch
            )
            target = reward_batch + self.gamma * max_q_next_state

        # 5. Cálculo del error de TD y pérdida ponderada
        td_error = q_current - target
        loss = (weights * td_error.pow(2)).mean()

        # 6. Optimización
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # 7. Actualización de prioridades
        new_priorities = (
            td_error.abs().detach().cpu().numpy() + 1e-5
        )  # para evitar cero
        self.memory.update_priorities(indices, new_priorities)

        return loss.item()

    def save_checkpoint(self, path, with_priority=False):
        """
        Save the current model state to a file in the DQN weights directory.
        """
        # check in folder weights/dqn latest version and assign version + 1
        version = 1
        import os

        if not with_priority:
            if os.path.exists("weights/dqn"):
                existing_versions = [
                    int(f.split("_version_")[-1])
                    for f in os.listdir("weights/dqn")
                    if f.startswith(path + "_version_")
                ]
                if existing_versions:
                    version = max(existing_versions) + 1
            save_path = f"weights/dqn/{path}_version_{version}"
            torch.save(self.policy_net.state_dict(), save_path)
        else:
            if os.path.exists("weights/dqn_prio"):
                existing_versions = [
                    int(f.split("_version_")[-1])
                    for f in os.listdir("weights/dqn_prio")
                    if f.startswith(path + "_version_")
                ]
                if existing_versions:
                    version = max(existing_versions) + 1
            save_path = f"weights/dqn_prio/{path}_version_{version}"
            torch.save(self.policy_net.state_dict(), save_path)
        print(f"Checkpoint saved to {save_path}")

    def load_checkpoint(self, path, with_priority=False):
        """
        Load the model state from a file in the DQN weights directory.
        """
        if not with_priority:
            load_path = f"weights/dqn/{path}"
        else:
            load_path = f"weights/dqn_prio/{path}"
        self.policy_net.load_state_dict(torch.load(load_path, map_location=self.device))
        print(f"Checkpoint loaded from {load_path}")

    def get_state_values(self, states):
        self.policy_net.eval()

        with torch.no_grad():
            q_values = [
                self.policy_net(state.unsqueeze(0)).max().item() for state in states
            ]

        # Volver a poner la red en modo de entrenamiento
        self.policy_net.train()

        return np.mean(np.array(q_values))
